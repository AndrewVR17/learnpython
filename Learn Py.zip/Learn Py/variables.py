#A variable is a place where you can store data, so for example
variable = "Hello "
#So the variable name, is equal to "Hello"
variable2 = "World!"

print(variable,variable2)
#This will make "Hello World!" Try it out with the play button!