#The for loop is if you assign something to it with a number, the number is how many times it will do it.
for i in range(3):
    print("Yo", i)
#So now, it prints Yo, 3 times.
# And you dont have to do i for everything
for cats in range(5):
    print("Cat", cats)
#See!
#But, if you play it, it says Cat 0, instead of Cat 1.
#There is a way to change that.
#Just add a plus and put 1.
print("Cats", cats + 1)