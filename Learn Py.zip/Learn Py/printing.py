#Printing is very simple, it just makes the computer say something. So if I do
print("Hello World!")
#This will now say, Hello World! Try it out, hit the play button.