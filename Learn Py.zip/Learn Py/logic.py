age = 50
likesCats = False
#These are just some data types



if age > 49:
    print("You are old!")
    #This is basically saying if your age is older than 49, we printed you are old!(make sure to use a colon sometimes)
elif age == 45:
    print("You are getting old.")
    #This is saying, if your age is 45, you are getting old. And elif means "else if"
else:
    print("you are NOT old")
#Now this is saying if you arent 45 or 49, you arent old

if likesCats:
    print("You like cats!")
#This is saying if likesCats is true, it will say, You like cats!
else:
    print("Why dont you like them")
#This is saying if likesCats isnt true, it will say, Why dont you like them!
#But right now likesCats is false, so if you change it to true, it will say, You like cats!