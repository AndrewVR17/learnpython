#Now, we are moving to math
#But have you realized that this file is called math_practice instead of math
#Well that is because Python for some reason doesnt let you name modules, files.
#So im just pointing that out, but lets get back to math.
a = 5
b = 5
c = 5
d = 5
#If you read datatypes.py, you know that a is equal to 5
#But math in py is very simple, this is it
addition = a + b
#All you have to do it put a, plus b. And that is it
#But, dont leave, we still have some more math things.
subtraction = c - d
division =  a/b
multiplication = c*d
#And if you print them,
print(addition)
print(subtraction)
print(division)
print(multiplication)
#Then you get a simple calculator, try it!